# ARTFOS GOLD — Production Vercel + Supabase

Portal member production: signal access, analysis, news, membership and USD performance. Tidak mengeksekusi trading.

## Deploy
1. Upload project ini ke Vercel.
2. Tambahkan Environment Variables di Vercel:
   - `SUPABASE_URL`
   - `SUPABASE_ANON_KEY` (anon/publishable key, BUKAN service_role)
3. Deploy.
4. Di Supabase SQL Editor, jalankan `sql/schema.sql`.
5. Buat akun admin pertama di Supabase Authentication.
6. Ambil UUID user tersebut lalu jalankan UPDATE admin di akhir `schema.sql`.

Tidak ada mode demo, akun palsu, atau password admin hard-coded.

## Production security
- RLS wajib aktif.
- Member hanya membaca signal yang punya entitlement membership.
- Member tidak dapat mengubah role/status/membership/signal/result/news.
- Broker verification hanya admin.
- Password tidak disimpan di tabel aplikasi dan tidak diekspor.
- `service_role` key tidak boleh masuk browser/Vercel client code.

## Real-time data
UI sudah siap menerima `news_events`, `signals`, dan `signal_results` dari backend. Economic calendar, market-data feed, TradingView/webhook, dan AI provider harus dihubungkan pada server-side worker/API yang Anda gunakan. Jangan memasukkan Actual/market price fiktif.
